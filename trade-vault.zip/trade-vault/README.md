# Trade Vault

Локальний торговий дашборд — Next.js 15 + Tailwind CSS 4 + TypeScript.

## Запуск

```bash
npm install
npm run dev
```

Відкрий http://localhost:3000 у браузері.

## Вкладки

| Вкладка    | Опис                                                   |
|------------|--------------------------------------------------------|
| Огляд      | KPI, Equity Curve, Monthly P&L, By Pair, Emotion stats |
| Журнал     | Таблиця угод + фільтри + форма додавання/редагування   |
| Ринок      | Correlation Map, Heatmap активності, TradingView live  |
| Календар   | Investing.com економічний календар + макроіндикатори   |
| Новини     | Геополітика + Макро + Forex + Crypto live стрічки      |
| Скріни     | Галерея скріншотів угод з TradingView                  |

## Структура

```
src/
  app/             — Next.js App Router
  components/      — UI компоненти та вкладки
  hooks/           — use-trades (React Context + CRUD)
  lib/             — trade-data (68 угод), utils-trade, utils
```

## Додавання нових угод

Натисни «Нова угода» у вкладці Журнал. Дані зберігаються в пам'яті (in-memory state).
Для перманентного зберігання — додай localStorage або SQLite (через Next.js API routes + better-sqlite3).